import pygame
import random
import os

# Get the directory of the current script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Construct absolute paths for resources
SOUND_PATH = os.path.join(BASE_DIR, "fast-collision-reverb-14611.mp3")
HIGHSCORE_PATH = os.path.join(BASE_DIR, "highscore.txt")

pygame.init()

print ("")
print ("Here are the rules!:\n1)Collect the black object and avoid the balls!\n2) Collecting one black object gives you 1 point!\n3) If the ball collides with the black object, your score gets subtracted by 1!\n4)If you have a negative score, the game quits!\n5) You have 60 seconds!\n6) You can move the character using the WASD keys!")

WIDTH, HEIGHT = 800, 600

WHITE = 255, 255, 255
RED = 255, 0, 0
BLACK = 0, 0, 0

FPS = 60
score = 0
time = 0
UPDATE_TIME = pygame.USEREVENT +1

sound = pygame.mixer.Sound("doorhit-98828.mp3")

pygame.time.set_timer(UPDATE_TIME, 1000)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame Window")

player = pygame.Rect(WIDTH//2 + 50, HEIGHT//2 + 50, 50, 50)
player_velocity = 7

collective_object = pygame.Rect(random.randint(35, WIDTH - 35), random.randint(40, HEIGHT - 40), 35, 35)

falling_objects = [
    pygame.Rect(random.randint(35, WIDTH - 35), 0, 50, 50),
    pygame.Rect(random.randint(35, WIDTH - 35), 0, 50, 50),
    pygame.Rect(random.randint(35, WIDTH - 35), 0, 50, 50)
]

falling_object_velocity = 5

clock = pygame.time.Clock()

def movement_of_the_player():
    key_pressed = pygame.key.get_pressed()
    
    if key_pressed[pygame.K_d] and player.x < WIDTH - player.width:
        player.x += player_velocity
    
    if key_pressed[pygame.K_a] and player.x > 0:
        player.x -= player_velocity
    
    if key_pressed[pygame.K_w] and player.y > 0:
        player.y -= player_velocity
    if key_pressed[pygame.K_s] and player.y < HEIGHT - 50:
        player.y += player_velocity

def game(time):
    global score
    run = True
    
    try:
        with open(HIGHSCORE_PATH) as f:
            highscore = f.read()
            highscore = int(highscore) if highscore else 0
    except FileNotFoundError:
        highscore = 0
    
    while run:
        screen.fill(WHITE)
        pygame.draw.rect(screen, (255, 190, 0), player)
        pygame.draw.rect(screen, (0, 0, 0), collective_object)
        
        for obj in falling_objects:
            pygame.draw.ellipse(screen, (RED), obj)
            obj.y += falling_object_velocity
            
            if obj.y > HEIGHT:
                obj.y = 0
                obj.x = random.randint(35, WIDTH - 35)
            
            if player.colliderect(obj):
                run = False
                print ("")
                print (f"Your score was {score}")
            
            for other_object in falling_objects:
                if obj != other_object and obj.colliderect(other_object):
                    obj.x = random.randint(35, WIDTH - 35)
                    break
            
            if obj.colliderect(collective_object):
                collective_object.x, collective_object.y = random.randint(35, WIDTH - 35), random.randint(35, HEIGHT - 35)
                score -= 1
                
            if score < 0:
                run = False
                print ("")
                print ("You had a negative score!")

        if player.colliderect(collective_object):
            pygame.draw.rect(screen, (RED), player)
            collective_object.x = random.randint(35, WIDTH - 35)
            collective_object.y = random.randint(35, HEIGHT - 35)
            score += 1
            sound.play()
        
        font = pygame.font.SysFont(None, 36)
        
        score_display = font.render(f"Score: {score}", True, (BLACK))
        screen.blit(score_display, (10, 10))
        
        time_display = font.render(f"Time: {time}s", True, (BLACK))
        screen.blit(time_display, (10, 50))
        
        rules_display = font.render("View the terminal for the rules!", True, (BLACK))
        screen.blit(rules_display, (200, 10))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == UPDATE_TIME:
                time += 1
            
        if time >= 61:
            run = False
            print ("")
            print ("Game Over!")
            print (f"Your score was {score}")
        
        movement_of_the_player()
        pygame.display.flip()
        clock.tick(FPS)
        
    if score > highscore:
        print(f"New Highscore! Previous: {highscore}, New: {score}")
        with open(HIGHSCORE_PATH, "w") as f:
            f.write(str(score))
    else:
        print (f"Score: {score}, Highscore: {highscore}")
    
    pygame.quit()
game(time)